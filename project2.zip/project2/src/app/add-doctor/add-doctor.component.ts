import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyserviceService, Doctors } from '../myservice.service';

@Component({
  selector: 'app-add-doctor',
  templateUrl: './add-doctor.component.html',
  styleUrls: ['./add-doctor.component.css']
})
export class AddDoctorComponent implements OnInit {
  message: string;

  constructor(private myservice: MyserviceService,private router: Router) { }

  ngOnInit(): void {
  }
  onSubmit(adddoctor:Doctors):any{
    console.log(adddoctor);
     this.myservice.addDoctor(adddoctor).subscribe(data => {
      this.message=data});
  }

}
