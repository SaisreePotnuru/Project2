import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-doctor',
  templateUrl: './update-doctor.component.html',
  styleUrls: ['./update-doctor.component.css']
})
export class UpdateDoctorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
